/*
Navicat MySQL Data Transfer

Source Server         : 10.100.22.168_mysql
Source Server Version : 50552
Source Host           : 10.100.22.168:3306
Source Database       : mb_safe

Target Server Type    : MYSQL
Target Server Version : 50552
File Encoding         : 65001

Date: 2018-07-20 09:25:32
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for safe_list
-- ----------------------------
DROP TABLE IF EXISTS `safe_list`;
CREATE TABLE `safe_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `profile` int(11) NOT NULL DEFAULT '1',
  `login_username` varchar(255) DEFAULT NULL,
  `login_password` varchar(255) DEFAULT NULL,
  `mode` int(11) NOT NULL DEFAULT '1',
  `is_mail` int(11) NOT NULL DEFAULT '1',
  `tool` int(11) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1：新建；2：进行中；3：已取消；4：完成',
  `update_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '更新时间',
  `create_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COMMENT='扫描申请列表';

-- ----------------------------
-- Records of safe_list
-- ----------------------------
INSERT INTO `safe_list` VALUES ('1', 'http://qa.it.mb.com/', '1', '', '', '1', '1', '0', '4', '2016-12-05 15:31:01', '2016-11-30 16:05:00');
INSERT INTO `safe_list` VALUES ('2', 'http://www.baidu.com', '1', '111', '222', '1', '1', '1', '4', '2016-11-30 18:50:00', '2016-11-30 18:40:23');
INSERT INTO `safe_list` VALUES ('3', 'http://qa.it.mb.com/', '1', '', '', '1', '1', '2', '4', '2016-12-01 09:40:00', '2016-12-01 09:27:35');
INSERT INTO `safe_list` VALUES ('4', 'http://qa.it.mb.com/', '3', '', '', '2', '2', '0', '3', '0000-00-00 00:00:00', '2016-12-01 13:43:52');
INSERT INTO `safe_list` VALUES ('5', 'http://qa.it.mb.com/', '8', '', '', '3', '1', '0', '4', '2016-12-01 13:50:00', '2016-12-01 13:44:29');
INSERT INTO `safe_list` VALUES ('6', 'http://10.100.22.169:8080/jenkins/', '1', '', '', '1', '1', '1', '4', '2016-12-02 09:00:00', '2016-12-02 08:52:43');
INSERT INTO `safe_list` VALUES ('7', 'http://www.iteye.com/magazines/132-Java-NIO', '1', '', '', '1', '1', '1', '4', '2016-12-09 10:27:21', '2016-12-02 09:09:15');
INSERT INTO `safe_list` VALUES ('11', 'http://qa.it.mb.com/', '1', '', '', '1', '1', '1', '3', '0000-00-00 00:00:00', '2016-12-02 13:32:07');
INSERT INTO `safe_list` VALUES ('12', 'http://www.baidu.com', '1', '', '', '1', '1', '1', '3', '0000-00-00 00:00:00', '2016-12-02 13:32:41');
INSERT INTO `safe_list` VALUES ('13', 'http://www.yiichina.com', '1', '', '', '1', '1', '1', '3', '0000-00-00 00:00:00', '2016-12-02 13:33:21');
INSERT INTO `safe_list` VALUES ('14', 'http://www.iteye.com/magazines/132-Java-NIO', '1', '', '', '1', '1', '1', '4', '2016-12-02 13:50:00', '2016-12-02 13:36:48');
INSERT INTO `safe_list` VALUES ('15', 'http://www.cnblogs.com/', '1', '', '', '3', '1', '1', '4', '2016-12-05 15:29:32', '2016-12-05 13:18:26');
INSERT INTO `safe_list` VALUES ('16', 'http://huodong.mbgo.com', '1', '', '', '3', '1', '0', '3', '2016-12-09 11:14:45', '2016-12-08 10:54:19');
INSERT INTO `safe_list` VALUES ('17', 'http://huodong.mbgo.com', '1', 'yuanjunlei', 'Aa1234567890_', '3', '1', '1', '4', '2016-12-09 10:18:38', '2016-12-08 14:45:39');
INSERT INTO `safe_list` VALUES ('18', 'http://huodong.mbgo.com', '1', '', '', '3', '1', '1', '4', '2016-12-09 10:05:17', '2016-12-09 09:50:32');
INSERT INTO `safe_list` VALUES ('19', 'http://huodong.mbgo.com/huodong/dan/index.html', '1', '', '', '3', '1', '1', '4', '2016-12-09 12:36:00', '2016-12-09 12:30:29');
INSERT INTO `safe_list` VALUES ('20', 'http://qa.it.mb.com/', '1', 'test', '123', '2', '1', '1', '4', '2016-12-13 15:18:24', '2016-12-13 15:12:11');
INSERT INTO `safe_list` VALUES ('21', 'http://www.iteye.com/magazines/132-Java-NIO', '1', '', '', '2', '1', '1', '4', '2017-01-17 17:30:00', '2017-01-17 17:25:25');
INSERT INTO `safe_list` VALUES ('22', 'http://qa.it.mb.com', '1', '', '', '2', '1', '1', '4', '2017-03-14 09:20:00', '2017-03-14 09:12:32');
INSERT INTO `safe_list` VALUES ('23', 'http://qa.it.mb.com/', '3', '', '', '1', '1', '0', '4', '2017-04-06 18:00:00', '2017-04-06 17:48:03');
INSERT INTO `safe_list` VALUES ('24', 'http://10.101.1.53:8080', '1', 'A00146U1001', 'Q^KD^dRI[5XP', '3', '1', '0', '4', '2017-04-07 10:20:00', '2017-04-07 10:12:43');
INSERT INTO `safe_list` VALUES ('25', 'http://10.101.1.53:8080/PosHttpService/rest/accessToken', '1', 'A00146U1001', 'Q^KD^dRI[5XP', '3', '1', '0', '4', '2017-04-07 10:30:05', '2017-04-07 10:22:18');
INSERT INTO `safe_list` VALUES ('26', 'http://10.101.1.53:8080', '1', 'A00146U1001', 'Q^KD^dRI[5XP', '3', '1', '0', '4', '2017-04-07 11:00:00', '2017-04-07 10:45:35');
INSERT INTO `safe_list` VALUES ('27', 'http://10.101.1.53:8080/PosHttpService/rest/accessToken', '1', 'A00146U1001', 'Q^KD^dRI[5XP', '3', '1', '0', '4', '2017-04-07 11:10:00', '2017-04-07 10:58:01');
INSERT INTO `safe_list` VALUES ('28', 'http://10.101.1.53:8080', '1', '', '', '2', '1', '0', '3', '2017-04-07 11:20:00', '2017-04-07 11:14:30');
INSERT INTO `safe_list` VALUES ('29', 'http://10.101.1.53:8080', '1', '', '', '2', '1', '0', '4', '2017-04-07 12:20:00', '2017-04-07 12:11:59');
INSERT INTO `safe_list` VALUES ('30', 'http://qa.it.mb.com', '1', '', '', '2', '1', '0', '4', '2017-04-07 13:56:10', '2017-04-07 13:37:00');
INSERT INTO `safe_list` VALUES ('31', 'http://10.101.1.53:8080', '1', '', '', '2', '1', '0', '4', '2017-04-07 14:59:06', '2017-04-07 13:37:23');
INSERT INTO `safe_list` VALUES ('32', 'http://10.101.1.53:8080/', '1', '', '', '2', '1', '0', '4', '2017-04-07 15:01:32', '2017-04-07 14:57:31');
INSERT INTO `safe_list` VALUES ('33', 'http://10.101.1.53:8080/PosHttpService/rest/billUpload/dataT', '1', '', '', '3', '1', '0', '4', '2017-04-10 10:20:00', '2017-04-10 09:57:50');
INSERT INTO `safe_list` VALUES ('34', 'http://10.101.1.53:8080/PosHttpService/rest/billUpload/dataD', '1', '', '', '3', '1', '0', '4', '2017-04-10 10:30:00', '2017-04-10 09:58:03');
INSERT INTO `safe_list` VALUES ('35', 'http://10.101.1.53:8080/PosHttpService/rest/billUpload/empty', '1', '', '', '3', '1', '0', '4', '2017-04-10 10:40:00', '2017-04-10 09:58:18');
INSERT INTO `safe_list` VALUES ('36', 'http://10.101.1.53:8080/PosHttpService/rest/billUpload/billD', '1', '', '', '3', '1', '0', '4', '2017-04-10 11:50:00', '2017-04-10 09:58:30');
INSERT INTO `safe_list` VALUES ('37', 'http://10.101.1.53:8080/PosHttpService/rest/download/getTabl', '1', '', '', '3', '1', '0', '4', '2017-04-10 12:00:00', '2017-04-10 09:58:41');
INSERT INTO `safe_list` VALUES ('38', 'http://10.101.1.53:8080/PosHttpService/rest/download/downSma', '1', '', '', '3', '1', '0', '4', '2017-04-10 12:10:00', '2017-04-10 09:58:52');
INSERT INTO `safe_list` VALUES ('39', 'http://10.101.1.53:8080/PosHttpService/rest/download/getServ', '1', '', '', '3', '1', '0', '4', '2017-04-10 13:30:00', '2017-04-10 09:59:03');
INSERT INTO `safe_list` VALUES ('40', 'http://10.101.1.53:8080/PosHttpService/rest/download/checkBr', '1', '', '', '3', '1', '0', '4', '2017-04-10 13:40:00', '2017-04-10 09:59:14');
INSERT INTO `safe_list` VALUES ('41', 'http://www.banggo.com', '1', '', '', '2', '1', '0', '3', '0000-00-00 00:00:00', '2017-04-27 14:39:54');
INSERT INTO `safe_list` VALUES ('42', 'http://qa.it.mb.com', '1', '11112', '22222', '3', '1', '0', '3', '2017-04-27 14:45:49', '2017-04-27 14:45:37');
INSERT INTO `safe_list` VALUES ('43', 'http://www.banggo.com', '1', '', '', '2', '1', '0', '4', '2017-04-27 15:00:00', '2017-04-27 14:50:08');
INSERT INTO `safe_list` VALUES ('44', 'http://10.100.22.219:8080', '1', 'test001', '123456', '2', '1', '0', '4', '2017-04-27 15:40:00', '2017-04-27 15:30:10');
INSERT INTO `safe_list` VALUES ('45', 'http://vd.metersbonwe.com/', '1', '15221262482', '123456', '2', '1', '0', '4', '2017-04-27 15:50:00', '2017-04-27 15:32:47');
INSERT INTO `safe_list` VALUES ('46', 'http://10.100.20.122:8080/CloudProdCheck/Export', '1', 'A01339U2859', 'HBOEx3qBobhOz6yO9AwfyA==', '2', '1', '0', '4', '2017-04-27 17:20:00', '2017-04-27 17:13:52');
INSERT INTO `safe_list` VALUES ('47', 'http://10.100.22.207:8080/OmsManager/', '1', 'HQ01UC285', '123456', '2', '1', '1', '4', '2017-05-10 14:40:00', '2017-05-10 14:34:44');
