/*
Navicat MySQL Data Transfer

Source Server         : 10.100.22.168_mysql
Source Server Version : 50552
Source Host           : 10.100.22.168:3306
Source Database       : mb_safe

Target Server Type    : MYSQL
Target Server Version : 50552
File Encoding         : 65001

Date: 2018-07-20 09:25:15
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for safe_ext
-- ----------------------------
DROP TABLE IF EXISTS `safe_ext`;
CREATE TABLE `safe_ext` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `safe_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_mail` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `update_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `create_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1 COMMENT='申请与用户关联表';

-- ----------------------------
-- Records of safe_ext
-- ----------------------------
INSERT INTO `safe_ext` VALUES ('1', '1', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2016-11-30 16:05:00');
INSERT INTO `safe_ext` VALUES ('2', '2', '2', 'zhuyiming@metersbonwe.com', '0000-00-00 00:00:00', '2016-11-30 18:40:23');
INSERT INTO `safe_ext` VALUES ('3', '3', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-01 09:27:35');
INSERT INTO `safe_ext` VALUES ('4', '4', '3', 'lujuan@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-01 13:43:52');
INSERT INTO `safe_ext` VALUES ('5', '5', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-01 13:44:29');
INSERT INTO `safe_ext` VALUES ('6', '6', '5', 'lijun11@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-02 08:52:43');
INSERT INTO `safe_ext` VALUES ('7', '7', '2', 'zhuyiming@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-02 09:09:15');
INSERT INTO `safe_ext` VALUES ('11', '11', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-02 13:32:07');
INSERT INTO `safe_ext` VALUES ('12', '12', '2', 'zhuyiming@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-02 13:32:41');
INSERT INTO `safe_ext` VALUES ('13', '13', '3', 'lujuan@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-02 13:33:22');
INSERT INTO `safe_ext` VALUES ('14', '14', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-02 13:36:49');
INSERT INTO `safe_ext` VALUES ('15', '15', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-05 13:18:26');
INSERT INTO `safe_ext` VALUES ('16', '16', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-08 10:54:19');
INSERT INTO `safe_ext` VALUES ('17', '17', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-08 14:45:39');
INSERT INTO `safe_ext` VALUES ('18', '18', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-09 09:50:32');
INSERT INTO `safe_ext` VALUES ('19', '19', '6', 'changhai@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-09 12:30:29');
INSERT INTO `safe_ext` VALUES ('20', '20', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2016-12-13 15:12:11');
INSERT INTO `safe_ext` VALUES ('21', '21', '2', 'zhuyiming@metersbonwe.com', '0000-00-00 00:00:00', '2017-01-17 17:25:25');
INSERT INTO `safe_ext` VALUES ('22', '22', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2017-03-14 09:12:32');
INSERT INTO `safe_ext` VALUES ('23', '23', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-06 17:48:03');
INSERT INTO `safe_ext` VALUES ('24', '24', '5', 'lijun11@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-07 10:12:43');
INSERT INTO `safe_ext` VALUES ('25', '25', '5', 'lijun11@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-07 10:22:18');
INSERT INTO `safe_ext` VALUES ('26', '26', '5', 'lijun11@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-07 10:45:35');
INSERT INTO `safe_ext` VALUES ('27', '27', '4', 'zhouyi5@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-07 10:58:01');
INSERT INTO `safe_ext` VALUES ('28', '28', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-07 11:14:30');
INSERT INTO `safe_ext` VALUES ('29', '29', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-07 12:11:59');
INSERT INTO `safe_ext` VALUES ('30', '30', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-07 13:37:00');
INSERT INTO `safe_ext` VALUES ('31', '31', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-07 13:37:23');
INSERT INTO `safe_ext` VALUES ('32', '32', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-07 14:57:31');
INSERT INTO `safe_ext` VALUES ('33', '33', '5', 'lijun11@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-10 09:57:50');
INSERT INTO `safe_ext` VALUES ('34', '34', '5', 'lijun11@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-10 09:58:03');
INSERT INTO `safe_ext` VALUES ('35', '35', '5', 'lijun11@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-10 09:58:18');
INSERT INTO `safe_ext` VALUES ('36', '36', '5', 'lijun11@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-10 09:58:30');
INSERT INTO `safe_ext` VALUES ('37', '37', '5', 'lijun11@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-10 09:58:41');
INSERT INTO `safe_ext` VALUES ('38', '38', '5', 'lijun11@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-10 09:58:52');
INSERT INTO `safe_ext` VALUES ('39', '39', '5', 'lijun11@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-10 09:59:03');
INSERT INTO `safe_ext` VALUES ('40', '40', '5', 'lijun11@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-10 09:59:14');
INSERT INTO `safe_ext` VALUES ('41', '41', '8', 'guoyanjun@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-27 14:39:54');
INSERT INTO `safe_ext` VALUES ('42', '42', '1', 'yuanjunlei@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-27 14:45:37');
INSERT INTO `safe_ext` VALUES ('43', '43', '8', 'guoyanjun@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-27 14:50:08');
INSERT INTO `safe_ext` VALUES ('44', '44', '9', 'taojinlan@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-27 15:30:10');
INSERT INTO `safe_ext` VALUES ('45', '45', '9', 'taojinlan@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-27 15:32:47');
INSERT INTO `safe_ext` VALUES ('46', '46', '8', 'guoyanjun@metersbonwe.com', '0000-00-00 00:00:00', '2017-04-27 17:13:52');
INSERT INTO `safe_ext` VALUES ('47', '47', '10', 'tanxiaofeng@metersbonwe.com', '0000-00-00 00:00:00', '2017-05-10 14:34:44');
