/*
Navicat MySQL Data Transfer

Source Server         : 10.100.22.168_mysql
Source Server Version : 50552
Source Host           : 10.100.22.168:3306
Source Database       : mb_safe

Target Server Type    : MYSQL
Target Server Version : 50552
File Encoding         : 65001

Date: 2018-07-20 09:25:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for safe_issues
-- ----------------------------
DROP TABLE IF EXISTS `safe_issues`;
CREATE TABLE `safe_issues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `safe_id` int(11) NOT NULL COMMENT '扫描申请id',
  `servers` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT '服务',
  `os` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT '系统',
  `language` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT '语言',
  `issues` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT '问题',
  `affects` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT '影响内容',
  `severity` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT '风险等级',
  `details` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT '详情',
  `request` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT '请求',
  `response` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT '响应',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='扫描结果';

-- ----------------------------
-- Records of safe_issues
-- ----------------------------
