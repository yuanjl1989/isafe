/*
Navicat MySQL Data Transfer

Source Server         : 10.100.22.168_mysql
Source Server Version : 50552
Source Host           : 10.100.22.168:3306
Source Database       : mb_safe

Target Server Type    : MYSQL
Target Server Version : 50552
File Encoding         : 65001

Date: 2018-07-20 09:25:41
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '员工编号',
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT '邮件地址(用户名)',
  `password_hash` varchar(255) NOT NULL DEFAULT '' COMMENT '密码哈希',
  `chinese_name` varchar(255) NOT NULL DEFAULT '' COMMENT '汉语名',
  `english_name` varchar(255) DEFAULT NULL COMMENT '英语名',
  `staff_no` varchar(30) NOT NULL DEFAULT '' COMMENT '工号',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除,0存在,1删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='员工基本表';

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'yuanjunlei@metersbonwe.com', '', '袁俊磊', 'yuanjunlei', 'HQ01UE317', '2016-11-30 15:49:29', '2016-11-30 15:49:29', '0');
INSERT INTO `user` VALUES ('2', 'zhuyiming@metersbonwe.com', '', '朱一明', 'zhuyiming', 'HQ01UE318', '2016-11-30 18:39:58', '2016-11-30 18:39:58', '0');
INSERT INTO `user` VALUES ('3', 'lujuan@metersbonwe.com', '', '陆娟(测试)', 'lujuan', 'HQ01UE263', '2016-12-01 11:07:27', '2016-12-01 11:07:27', '0');
INSERT INTO `user` VALUES ('4', 'zhouyi5@metersbonwe.com', '', '周翊', 'zhouyi5', 'HQ01UE927', '2016-12-01 18:05:55', '2016-12-01 18:05:55', '0');
INSERT INTO `user` VALUES ('5', 'lijun11@metersbonwe.com', '', '李军', 'lijun11', 'HQ01UF441', '2016-12-02 08:52:14', '2016-12-02 08:52:14', '0');
INSERT INTO `user` VALUES ('6', 'changhai@metersbonwe.com', '', '常海', 'changhai', 'HQ01UE592', '2016-12-09 12:29:15', '2016-12-09 12:29:15', '0');
INSERT INTO `user` VALUES ('7', 'zhengliang@metersbonwe.com', '', '郑亮', 'zhengliang', 'HQ01UD935', '2017-04-24 11:11:02', '2017-04-24 11:11:02', '0');
INSERT INTO `user` VALUES ('8', 'guoyanjun@metersbonwe.com', '', '郭艳君', 'guoyanjun', 'HQ01UB507', '2017-04-27 14:39:05', '2017-04-27 14:39:05', '0');
INSERT INTO `user` VALUES ('9', 'taojinlan@metersbonwe.com', '', '陶进兰', 'taojinlan', 'HQ01UF509', '2017-04-27 15:26:52', '2017-04-27 15:26:52', '0');
INSERT INTO `user` VALUES ('10', 'tanxiaofeng@metersbonwe.com', '', '谭晓峰', 'tanxiaofeng', 'HQ01UC285', '2017-05-10 14:34:03', '2017-05-10 14:34:03', '0');
